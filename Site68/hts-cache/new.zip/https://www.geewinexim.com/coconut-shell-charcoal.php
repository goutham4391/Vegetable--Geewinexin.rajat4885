<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Geewin Exim is the largest Fresh Coconut Copra Wholesale Exporters & Suppliers.We are exporting these fresh coconut copras at most competitive prices." />
<meta name="keywords" content="" />

<!-- Page Title -->
<title>Geewin Exim - Coconut Shell Charcoal</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-green.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<link href="css/style.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.0.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

</head>
<body class="has-side-panel side-panel-right fullwidth-page side-push-panel">

	 <!-- preloader 
  <div id="preloader">
    <div id="spinner">
      <i class=" flaticon-gardening-power font-60 text-theme-colored floating"></i>
      <h5 class="line-height-50 font-18">Loading...</h5>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
  </div> -->

  <!-- Header -->
  <header id="header" class="header">
    <div class="header-middle p-0 xs-text-center">
      <div class="container pt-0 pb-0">
        <div class="row">
          <div class="col-xs-12 col-sm-3 col-md-3">
            <div class="widget no-border m-0">
              <a href="index.php" class="menuzord-brand pull-left flip xs-pull-center mt-20 mb-10"><img alt="" src="images/logo.jpg"></a>
            </div>
          </div>

          <div class="col-xs-12 col-sm-9 col-md-9">
            <div class="widget no-border m-0 hidden-xs">
              <div class="text-right flip sm-text-center">

              <!-- Portfolio Gallery Grid -->
              <div id="grid" class="gallery-isotope grid-3 gutter clearfix">
                <!-- Portfolio Item Start -->
                <div class="mt-15">
                      <a data-lightbox="image" href="images/certificates/certificate-star-1.jpg"><img src="images/certificates/logo-certificate-star-1.png" width="70"></a>
                      <a data-lightbox="image" href="images/certificates/certificate2.jpg"><img src="images/certificates/logo-certificate1.jpg" width="70"></a>
                      <a data-lightbox="image" href="images/certificates/certificate1.jpg"><img src="images/certificates/logo-certificate2.jpg" width="100"></a>
                      <a data-lightbox="image" href="images/certificates/apeda.jpg"><img src="images/certificates/apeda-small.jpg" width="70"></a>
                      <a data-lightbox="image" href="images/certificates/madurai.jpg"><img src="images/certificates/estd.jpg" width="70"></a>
                      <a href="http://trustseal.indiamart.com/members/geewinexim/" target="_blank"><img src="images/certificates/trust-seal.jpg" width="70"></a>
                </div>
                <!-- Portfolio Item End -->
                
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
</div>

    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-blue1">
        <div class="container">
          <nav id="menuzord" class="menuzord orange">
            
            <ul class="menuzord-menu">
              
              <li><a href="index.php">Home</a></li>

              <li><a href="profile.php">Profile</a>
                <ul class="dropdown">
                      <li><a href="about.php">About Us</a></li>
                      <li><a href="profile.php#vision">Vision & Mission</a></li>
                      <li><a href="management-team.php">Management team</a></li>
                      <li><a href="infrastructure.php">Infrastructure</a></li>
                      <li><a href="profile.php#quality">Quality assuarance</a></li>
                      <li><a href="profile.php#whyus">Why us</a></li>
                      <li><a href="profile.php#clientele">Clientele</a></li>
                      <li><a href="profile.php#testimonial">Testimonial</a></li>
                </ul>
              </li>

              <li><a href="products.php">Products</a>
                <div class="megamenu">
                  <div class="megamenu-row">
                    <div class="col6">
                      <ul class="list-unstyled list-dashed">
                          <li><a href="cavendish-banana.php">Cavendish Banana</a></li>
                          <li><a href="indian-coconut.php">Indian Coconut</a></li>
                          <li><a href="coconut-copra.php">Coconut Copra</a></li>
                          <li><a href="coconut-shell.php">Coconut shell</a></li>
                          <li><a href="coconut-shell-charcoal.php">Coconut shell charcoal</a></li>
                          <li><a href="desiccated-coconut-powder.php">Desiccated Coconut Powder</a></li>
                          <li><a href="indian-rice.php">Indian Rice</a></li>
                          <li><a href="coir-fiber.php">Coir Fiber</a></li>
                          <li><a href="cocopeat-block.php">Cocopeat Block</a></li>
                      </ul>
                    </div>
                    <div class="col6">
                      <ul class="list-unstyled list-dashed">
                          
						  <li><a href="grains-and-pulses.php">Grains and Pulses</a></li>
                          <li><a href="turmeric-finger.php">Turmeric Finger</a></li>
                          <li><a href="dry-red-chilly.php">Dry Red Chilli</a></li>
                          <li><a href="onion.php">Onion</a></li>
                          <li><a href="potato.php">Potato</a></li>
                      </ul>
                    </div>

                  </div>
                </div>
              </li>
              
              <li><a href="safety-matches.php">Safety Matches</a>
                <ul class="dropdown">
                      <li><a href="cardboard-match-boxes.php">Cardboard Match Boxes</a></li>
                      <li><a href="barbecue-matches.php">Barbecue Matches</a></li>
                      <li><a href="hotel-matches.php">Hotel Matches</a></li>
                      <li><a href="wax-match-box.php">Wax Match Box</a></li>
                      <li><a href="book-match-box.php">Book Match Box</a></li>
                      <li><a href="box-type-matches.php">Box Type Matches</a></li>
                      <li><a href="jumbo-match-boxes.php">Jumbo Match Boxes</a></li>
                      <li><a href="tent-shape-matches.php">Tent Shape Matches</a></li>
                      <li><a href="veneer-match-boxes.php">Veneer Match Boxes</a></li>
                      <li><a href="kitchen-match-boxes.php">Kitchen Match Boxes</a></li>
                </ul>
              </li>

              

              <li><a href="certificates.php">Certificates</a></li>

              <li><a href="brands.php">Our Brands</a></li>

              <li><a href="#">Gallery</a>
                <ul class="dropdown">
                      <li><a href="images.php">Images</a></li>
                      <li><a href="video.php">Videos</a></li>
                </ul>
              </li>

               <li><a href="event.php">Events</a></li>
              

              <li><a href="contact.php">Contact us</a></li>
			  <li  class="active"><a href="price-details.php"><i class="fa fa-dollar"></i> Price Watch</a></li>

            </ul>
          </nav>
        </div>
      </div>
    </div>

  </header>
  

  
    <div class="wtsapp" onclick="ga('send', 'event', 'whatsapp', 'click', 'Whatsapp Contact');">
      <div class="wtsicon" onclick="return openwtsapp()">
        <i class="fa fa-whatsapp"></i>
      </div>
      <a href="https://api.whatsapp.com/send?phone=919159773337" target="_blank">
        <div class="hidme" id="msg">
          <h4>Geewin Exim</h4>
          <h6>Contact Geewin Sales Team through WhatsApp.</h6>
        </div>
      </a>
    </div>


<script>
function openwtsapp() {
    document.getElementById("msg").style.visibility = "visible";
    document.getElementById("msg").style.left = "25px";
}
</script>

      

    <!-- <script type="text/javascript">
      $(document).ready(function() {
        $(".wtsapp").click(function() {
          $(".hidme").css("visibility","visible" "left","30px")
        });
      });
    </script> -->

  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header bg-green">
      
      <div class="container-fluid p-0">
        <!-- Section Content -->
        <img src="images/banner/coconut-shell-charcoal-1.jpg" class="img-fullwidth" alt="indian-rice">
      </div>
      
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-sm-12">
              <ol class="breadcrumb white mt-10 text-center">
                <li><a href="index.php"><i class="fa fa-home"></i></a></li>
                <li><a href="products.php">Products</a></li>
				<li class="active">Coconut Shell Charcoal </li>
              </ol>
            </div>
          </div>
        </div>
    </section>
    
    <!-- Section: About -->
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          	<h2 class="title-pattern mt-0 mb-10">Coconut Shell Charcoal </h2>
            <p>Geewin Exim is one of the topmost Coconut based Product Exporters in India. We have been operating for many years and are dealing with a number of clients from various parts of the globe Our services are unmatchable because of the excellence and the quality of our products</p>
			<p>Coconut Shell charcoal is used widely as domestic and industrial fuel. It is also used by foundries Activated Carbon produced from coconut shell has certain specific advantages as the raw material can adsorb certain molecules and because of its density retains good strength and physical properties.</p>
			<p>First of all, it is completely eco-friendly product, which is made from sustainable natural resources.</p>
			<p>Coconut Shell Charcoal is made from the process of carbonization through destructive distillation. In this process, the coconut shells undergo incomplete burning in oxygen-controlled environment. Tons of coconut shells are processed to prepare coal which is made available in convenient ovoid and annular ring...</p>
			<p>We offer good quality Coconut Shell Charcoal which is made from the process of Carbonization. Shell charcoal is used widely as domestic and industrial fuel.</p>
			<p>In Many Developing Countries (such as Indonesia, India, Malaysia) Charcoal is the Primary Cooking Fuel for urban and rural Household and restaurants. The demand of restaurant Charcoal has increased rapidly, and we are able to supply best Quality, Furthermore its burning power is awesome! It is Ideal for BBQ Grill, Traditional baking and Cooking etc..</p>
            
		<!--<ul class="list">
				<li> Edible Copra</li>
				<li> Milling Copra</li>
				<li> Ball Copra</li>
			</ul>-->
			
			
			<div class="owl-carousel-3col mt-10" data-dots="true">
                <div class="item">
                  <div class="team-member maxwidth400">
                    <div class="thumb"><img alt="" src="images/products/charcoal-1.jpg" class="img-fullwidth"></div>
                  </div>
                </div>
                <div class="item">
                  <div class="team-member maxwidth400">
                    <div class="thumb"><img alt="" src="images/products/charcoal-2.jpg" class="img-fullwidth"></div>
                  </div>
                </div>
				<div class="item">
                  <div class="team-member maxwidth400">
                    <div class="thumb"><img alt="" src="images/products/charcoal-3.jpg" class="img-fullwidth"></div>
                  </div>
                </div>
                
            </div>
		<!--	
			<p><b>Use:</b> Dry Coconut (or) Edible Copra is usually a perfect, well dried half cup of the coconut kernel and is used in various food preparations as well as a tasty nut.
			<p><b>Use:</b> Milling Copra consists of non-uniform dried pieces of coconut which are used mainly for the manufacture of coconut oil.
			<p><b>Use:</b> Ball Copra is usually a perfect, well dried whole of the coconut kernel and is used in various food preparations as well as a tasty nut.</p>
			-->
			
		<!--<ul class="list">
				<li>Hygienically processed</li>
				<li>Adulteration free</li>
				<li>Reasonable prices</li>
				<li>Natural and fresh</li>
			</ul>-->	
			
			
		<!--<h4 class="text-theme-colored">Specification of Copra:</h4>
			<table class="table table-bordered table-inverse">
                	<tr>
                    	<th>Parameters</th>
						<th>Edible Copra</th>	
						<th>Milling Copra</th>
					</tr>
					<tr>
                    	<td>Moisture</td>		
						<td>5% max	</td>	
						<td>5% max</td>	
					</tr>
					<tr>
                    	<td>Broken, Wrinkled or Germinated Cups	</td>
						<td>1% max	</td>
						<td>-</td>	
					</tr>
					<tr>
                    	<td>Mouldy Cups	</td>
						<td>Nil	</td>
						<td>2% max</td>	
					</tr>
					<tr>
                    	<td>Discoloured	</td>	
						<td>2% max	</td>	
						<td>-</td>	
					</tr>
					<tr>
                    	<td>Cups</td>	
						<td></td>	
						<td></td>	
					</tr>
					<tr>
                    	<td>Oil Content	</td>
						<td>65% min	</td>
						<td>65% min</td>	
					</tr>
					<tr>
                    	<td>Free Fatty Acid	</td>
						<td>0.3% max</td>	
						<td>0.3%</td>	
					</tr>
					<tr>
                    	<td>Crude Protein</td>
						<td>-</td>	
						<td>-</td>	
					</tr>
					<tr>
                    	<td>Crude Fibre</td>
						<td>-</td>	
						<td>-</td>	
					</tr>
					<tr>
                    	<td>Fat</td>
						<td>-</td>	
						<td>-</td>	
					</tr>
			</table>-->
			
		<div class="col-md-6">
			<h4 class="text-theme-colored">Product Specification :</h4>
			<table class="table table-bordered table-inverse">
                	<tr>
                    	<th>Product </th>
						<td>Coconut shell Char coal </td>
					</tr>
					<tr>
                    	<th>Moisture </th>
						<td>15%</td>
					</tr>
					<tr>
                    	<th>Dust </th>
						<td>3%</td>
					</tr>
					<tr>
                    	<th>Ash </th>
						<td>2%</td>
					</tr>
			</table>
			
		</div>
		
		<div class="col-md-6">	
			<h4 class="text-theme-colored">Packing </h4>
			<p>25 kg/50kg Bags</p>
			
			<h4 class="text-theme-colored">Load-ability</h4>
			<ul class="list">
				<li>Load ability of 20ft container : 12.5 Metric Ton</li>
				<li>Load ability of 40ft container : 25 Metric Ton</li>
			</ul>
			
		</div>
		<div class="clearfix"></div>
		<div class="col-md-6">	
			<h4 class="text-theme-colored">Payment Terms</h4>
			<p>TT- 35% Advance and 65% against scanned copy of shipment documents / Irrevocable L/C (with prime bank)</p>
		</div>
		
		</div>
      </div>
    </section>
  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
  
  	
  <section id="contact" class="form-bg">
      <div class="container pt-0 pb-0">
  	    <div class="section-content">
          <div class="row">
          	<div class="col-md-12 text-center">
                <h1 class="mt-100 mb-30 blue1 ft-24">LET'S GET IN TOUCH</h1>
                <p class="mb-30 text-white">Here are the packages that we offer and they all include refreshments.</p>
          	</div>
            <div class="col-sm-12 col-md-12">
              <div class="contact-wrapper">

				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Error Message -->  
	<div id="success_message" style="width:100%; height:100%; display:none; text-align:center;"> <h3 class="text-white">Sent your message successfully!</h3> </div>
	<div class="text-white" id="error_message" style="width:100%; height:100%; display:none; text-align:center;"> <h3>Error</h3> Sorry there was an error sending your form. </div>
<!-- Error Message End--> 


<!-- Form Start -->               
	<form role="form" method="post" id="reused_form" >
		<div class="col-sm-12 col-md-6">
			<div class="form-group">   
	            <input type="text" class="form-control form-input" id="name" name="name" placeholder="Name" required maxlength="50">
			</div>
			<div class="form-group"> 
				<input type="email" class="form-control form-input" id="email" name="email" placeholder="Email"  required maxlength="50">
			</div>
			<div class="form-group">
				<input type="phone" class="form-control form-input" id="phone" name="phone" placeholder="Phone Number" required maxlength="50">
			</div>
			<div class="form-group">
				<input type="text" class="form-control form-input" id="city" name="city" placeholder="Your City / State / Country*" required maxlength="50">
			</div>
		</div>
		<div class="col-sm-12 col-md-6">
			<div class="form-group">
				<textarea class="form-control form-input" type="textarea" name="message" id="message" placeholder="Your Message Here" maxlength="6000" rows="7"></textarea>
			</div>
			<div class="form-group col-md-12" style="padding: 0;">
				<div class="form-group col-md-4" style="padding: 0;">
					<img src="mail/captcha.php" id="captcha_image" style="height: 45px;"/> <a id="captcha_reload" href="#"> <i class="fa fa-refresh fa-lg" style="color: white;"></i> </a> 
				</div>
				<div class="form-group col-md-8" style="padding: 0;">
					<input type="text" class="form-control form-input" placeholder="Enter the code from the image" required id="captcha" name="captcha" >
				</div>
			</div>
		</div>
        <div class="col-md-12 text-center mb-30">
			<input type="submit" class="btn bg-blue2 text-white" align="middle"  id="btnContactUs" value="SEND MESSAGE"></input>
		</div>
	</form>
	
<!-- Script for captcha load -->	
	
	<script type="text/javascript" src="./mail/form.js"></script>
<!-- Script for captcha load End-->	
              </div>
            </div>
          </div>
  	    </div>
      </div>
    </section>
  <!-- Footer -->
  
  <footer id="footer" class="bg-black-222" data-bg-img="images/footer-bg.png" data-bg-color="#e3e3e3">
    <div class="container pt-70 pb-30">
      <div class="row border-bottom-black">
        <div class="col-sm-6 col-md-6">
          <div class="widget dark text-center">
            <img class="mb-20" alt="" src="images/foot-logo.png">
            <p class="text-black-333">We GEEWIN EXIM, Madurai is one of the leading merchant exporters in India. We are supplying high quality of Cavendish banana, Rice, Fresh Vegetables, Indian Spices, Coconut, Coco peat, Cashew Nuts, Chickpeas, Chilly in large volumes to our customers’ spread through out the world. We are based at Madurai the hub of Exporter’s House. We here the capability to deliver large volumes with in stipulated time schedules.</p>
          </div>
        </div>
        <!--<div class="col-sm-6 col-md-2">
          <div class="widget">
            <h5 class="widget-title line-bottom blue1">Profile</h5>
            <ul class="list angle-double-right list-border">
                <li><a href="about.html">About Us</a></li>
                <li><a href="profile.html#vsnmsn">Vision &amp; Mission</a></li>
                <li><a href="management-team.html">Management team</a></li>
                <li><a href="infrastructure.html">Infrastructure</a></li>
                <li><a href="profile.html#qual">Quality assurance</a></li>
        				<li><a href="profile.html#why">Why us</a></li>
        				<li><a href="profile.html#client">Clientele</a></li>
        				<li><a href="profile.html#test">Testimonial</a></li>
            </ul>
          </div>
        </div> -->
        <div class="col-sm-6 col-md-6 text-center">
          <div class="widget">
            <h5 class="widget-title blue1">OUR PRODUCTS</h5>

            <div class="tags">
              <a class="hvr-shrink" href="cavendish-banana.php">Cavendish Banana</a>
              <a class="hvr-shrink" href="indian-coconut.php">Indian Coconut</a>
              <a class="hvr-shrink" href="indian-rice.php">Indian Rice</a>
              <a class="hvr-shrink" href="coir-fiber.php">Coir Fiber</a>
              <a class="hvr-shrink" href="cocopeat-block.php">Cocopeat Block</a>
              <a class="hvr-shrink" href="gherkins.php">Gherkins</a>
				      <a class="hvr-shrink" href="indian-spices.php">Indian Spices</a>
              <a class="hvr-shrink" href="turmeric-finger.php">Turmeric Finger</a>
              <a class="hvr-shrink" href="dry-red-chilly.php">Dry Red Chilli</a>
            
              <a class="hvr-shrink" href="nuts.php">Nuts</a>
              <a class="hvr-shrink" href="grains-and-pulses.php">Grains and Pulses</a>
              <a class="hvr-shrink" href="chicken-eggs.php">Chicken Eggs</a>
              <a class="hvr-shrink" href="safety-matches.php">Safety Matches</a>
              <a class="hvr-shrink" href="onion.php">Onion</a>
              <a class="hvr-shrink" href="potato.php">Potato</a>
              <a class="hvr-shrink" href="fresh-vegetables.php">Fresh Vegetables</a>
              <a class="hvr-shrink" href="coconut-copra.php">Coconut Copra</a><br/>
			  <a class="hvr-shrink" href="event.php">Events</a>
             
          </div>
        </div>
      
      </div>
      </div>
      <div class="row mt-30">
        <div class="col-md-3">
          <div class="widget dark">
            
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10 text-black-333"> <i class="fa fa-map blue2 mr-5"></i> No.14, Sonaiyar Kovil Street, <br> Narimedu, Madurai, <br> Tamilnadu, India – 625 002.</li>
            </ul>

          </div>
        </div>
        <div class="col-md-3 col-md-offset-1">
          <div class="widget dark">
            
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10 text-black-333"><a href="tel:+919159773337"> <i class="fa fa-whatsapp blue2 mr-5"></i> +91 9159773337</a></li>
              <li class="m-0 pl-10 pr-10 text-black-333"> <i class="fa fa-skype blue2 mr-5"></i> Geewinexim</li>
            </ul>

          </div>
        </div>
        <div class="col-md-3">
          <div class="widget dark">
            <h5 class="widget-title mb-10 blue1">Connect With Us</h5>
            <ul class="styled-icons icon-dark icon-circled icon-sm">
              <li><a href="https://www.facebook.com/geewineximexporters/" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/EximGeewin" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="http://linkedin.com/company/geewineximindia" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.youtube.com/channel/UCqxAHV_Sv6_k3mzVMMu_Lww" target="_blank"><i class="fa fa-youtube"></i></a></li>
              <li><a href="https://www.instagram.com/geewinexim/" target="_blank"><i class="fa fa-instagram"></i></a></li>
              <li><a href="https://pinterest.com/geewineximexport/" target="_blank"><i class="fa fa-pinterest"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom bg-black-333">
      <div class="container pt-20 pb-20">
        <div class="row">
          <div class="col-md-6">
            <p class="font-11 text-gray-lighter pt-20 m-0">Copyright &copy;2022. All Rights Reserved</p>
          </div>
          <div class="col-md-6 text-right">
            <div class="no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12 text-gray-lighter">
                <li>
                  Design and Marketed By <a href="http://onedotm.com/" target="_blank"><img src="images/onedotlogo.png" alt="onedot media" width="70"></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>


  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-129500425-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-129500425-1');
</script>                  
 <!--        
<script>
document.addEventListener('contextmenu', event => event.preventDefault());
</script> -->

<script>(function(w, d) { w.CollectId = "5f7174beb54ea90b9bbc4d39"; var h = d.head || d.getElementsByTagName("head")[0]; var s = d.createElement("script"); s.setAttribute("type", "text/javascript"); s.async=true; s.setAttribute("src", "https://collectcdn.com/launcher.js"); h.appendChild(s); })(window, document);</script>
  
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>
</html>
