<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Geewin Exim is one of the leading Coconut wholesale exporters & suppliers in India.We are offering a wide collection of fresh coconuts that are acquired from new gardens and farms." />
<meta name="keywords" content="" />

<!-- Page Title -->
<title>Geewin Exim - Coconut Wholesale Exporters & Suppliers in India</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-green.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<link href="css/style.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.0.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>


<script type='application/ld+json'> 
	{
	"@context": "http://www.schema.org/",
	"@type": "Product",
	"brand": "Geewin Exim",
	"logo": "https://www.geewinexim.com/images/logo.jpg",
	"name": "Indian Coconut",
	"category": "Coconut",
	"image": "https://www.geewinexim.com/images/banner/indian-coconut.jpg",
	"description": "Geewin Exim is one of the leading Coconut wholesale exporters & suppliers in India.We are offering a wide collection of fresh coconuts that are acquired from new gardens and farms.",
	"aggregateRating":
	 {
	"@type": "aggregateRating",
	"ratingValue": "4.8",
	"reviewCount": "61"
	}
	}
</script>



</head>
<body class="has-side-panel side-panel-right fullwidth-page side-push-panel">

	 <!-- preloader 
  <div id="preloader">
    <div id="spinner">
      <i class=" flaticon-gardening-power font-60 text-theme-colored floating"></i>
      <h5 class="line-height-50 font-18">Loading...</h5>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
  </div> -->

  <!-- Header -->
  <header id="header" class="header">
    <div class="header-middle p-0 xs-text-center">
      <div class="container pt-0 pb-0">
        <div class="row">
          <div class="col-xs-12 col-sm-3 col-md-3">
            <div class="widget no-border m-0">
              <a href="index.php" class="menuzord-brand pull-left flip xs-pull-center mt-20 mb-10"><img alt="" src="images/logo.jpg"></a>
            </div>
          </div>

          <div class="col-xs-12 col-sm-9 col-md-9">
            <div class="widget no-border m-0 hidden-xs">
              <div class="text-right flip sm-text-center">

              <!-- Portfolio Gallery Grid -->
              <div id="grid" class="gallery-isotope grid-3 gutter clearfix">
                <!-- Portfolio Item Start -->
                <div class="mt-15">
                      <a data-lightbox="image" href="images/certificates/certificate-star-1.jpg"><img src="images/certificates/logo-certificate-star-1.png" width="70"></a>
                      <a data-lightbox="image" href="images/certificates/certificate2.jpg"><img src="images/certificates/logo-certificate1.jpg" width="70"></a>
                      <a data-lightbox="image" href="images/certificates/certificate1.jpg"><img src="images/certificates/logo-certificate2.jpg" width="100"></a>
                      <a data-lightbox="image" href="images/certificates/apeda.jpg"><img src="images/certificates/apeda-small.jpg" width="70"></a>
                      <a data-lightbox="image" href="images/certificates/madurai.jpg"><img src="images/certificates/estd.jpg" width="70"></a>
                      <a href="http://trustseal.indiamart.com/members/geewinexim/" target="_blank"><img src="images/certificates/trust-seal.jpg" width="70"></a>
                </div>
                <!-- Portfolio Item End -->
                
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
</div>

    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-blue1">
        <div class="container">
          <nav id="menuzord" class="menuzord orange">
            
            <ul class="menuzord-menu">
              
              <li><a href="index.php">Home</a></li>

              <li><a href="profile.php">Profile</a>
                <ul class="dropdown">
                      <li><a href="about.php">About Us</a></li>
                      <li><a href="profile.php#vision">Vision & Mission</a></li>
                      <li><a href="management-team.php">Management team</a></li>
                      <li><a href="infrastructure.php">Infrastructure</a></li>
                      <li><a href="profile.php#quality">Quality assuarance</a></li>
                      <li><a href="profile.php#whyus">Why us</a></li>
                      <li><a href="profile.php#clientele">Clientele</a></li>
                      <li><a href="profile.php#testimonial">Testimonial</a></li>
                </ul>
              </li>

              <li><a href="products.php">Products</a>
                <div class="megamenu">
                  <div class="megamenu-row">
                    <div class="col6">
                      <ul class="list-unstyled list-dashed">
                          <li><a href="cavendish-banana.php">Cavendish Banana</a></li>
                          <li><a href="indian-coconut.php">Indian Coconut</a></li>
                          <li><a href="coconut-copra.php">Coconut Copra</a></li>
                          <li><a href="coconut-shell.php">Coconut shell</a></li>
                          <li><a href="coconut-shell-charcoal.php">Coconut shell charcoal</a></li>
                          <li><a href="desiccated-coconut-powder.php">Desiccated Coconut Powder</a></li>
                          <li><a href="indian-rice.php">Indian Rice</a></li>
                          <li><a href="coir-fiber.php">Coir Fiber</a></li>
                          <li><a href="cocopeat-block.php">Cocopeat Block</a></li>
                      </ul>
                    </div>
                    <div class="col6">
                      <ul class="list-unstyled list-dashed">
                          
						  <li><a href="grains-and-pulses.php">Grains and Pulses</a></li>
                          <li><a href="turmeric-finger.php">Turmeric Finger</a></li>
                          <li><a href="dry-red-chilly.php">Dry Red Chilli</a></li>
                          <li><a href="onion.php">Onion</a></li>
                          <li><a href="potato.php">Potato</a></li>
                      </ul>
                    </div>

                  </div>
                </div>
              </li>
              
              <li><a href="safety-matches.php">Safety Matches</a>
                <ul class="dropdown">
                      <li><a href="cardboard-match-boxes.php">Cardboard Match Boxes</a></li>
                      <li><a href="barbecue-matches.php">Barbecue Matches</a></li>
                      <li><a href="hotel-matches.php">Hotel Matches</a></li>
                      <li><a href="wax-match-box.php">Wax Match Box</a></li>
                      <li><a href="book-match-box.php">Book Match Box</a></li>
                      <li><a href="box-type-matches.php">Box Type Matches</a></li>
                      <li><a href="jumbo-match-boxes.php">Jumbo Match Boxes</a></li>
                      <li><a href="tent-shape-matches.php">Tent Shape Matches</a></li>
                      <li><a href="veneer-match-boxes.php">Veneer Match Boxes</a></li>
                      <li><a href="kitchen-match-boxes.php">Kitchen Match Boxes</a></li>
                </ul>
              </li>

              

              <li><a href="certificates.php">Certificates</a></li>

              <li><a href="brands.php">Our Brands</a></li>

              <li><a href="#">Gallery</a>
                <ul class="dropdown">
                      <li><a href="images.php">Images</a></li>
                      <li><a href="video.php">Videos</a></li>
                </ul>
              </li>

               <li><a href="event.php">Events</a></li>
              

              <li><a href="contact.php">Contact us</a></li>
			  <li  class="active"><a href="price-details.php"><i class="fa fa-dollar"></i> Price Watch</a></li>

            </ul>
          </nav>
        </div>
      </div>
    </div>

  </header>
  

  
    <div class="wtsapp" onclick="ga('send', 'event', 'whatsapp', 'click', 'Whatsapp Contact');">
      <div class="wtsicon" onclick="return openwtsapp()">
        <i class="fa fa-whatsapp"></i>
      </div>
      <a href="https://api.whatsapp.com/send?phone=919159773337" target="_blank">
        <div class="hidme" id="msg">
          <h4>Geewin Exim</h4>
          <h6>Contact Geewin Sales Team through WhatsApp.</h6>
        </div>
      </a>
    </div>


<script>
function openwtsapp() {
    document.getElementById("msg").style.visibility = "visible";
    document.getElementById("msg").style.left = "25px";
}
</script>

      

    <!-- <script type="text/javascript">
      $(document).ready(function() {
        $(".wtsapp").click(function() {
          $(".hidme").css("visibility","visible" "left","30px")
        });
      });
    </script> -->

  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header bg-green">
      
      <div class="container-fluid p-0">
        <!-- Section Content -->
        <img src="images/banner/indian-coconut.jpg" class="img-fullwidth" alt="indian-coconut">
      </div>
      
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-sm-12">
              <ol class="breadcrumb white mt-10 text-center">
                <li><a href="index.php"><i class="fa fa-home"></i></a></li>
                <li><a href="products.php">Products</a></li>
                <li class="active">Indian Coconut</li>
              </ol>
            </div>
          </div>
        </div>
    </section>
    
    <!-- Section: About -->
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          	<h2 class="title-pattern mt-0 mb-10">Indian Coconut</h2>
            <p class="text-theme-colored"></p>
            <p>Geewin is one of the topmost fresh coconut exporters in India. We supply fresh, semi-husked coconuts. Our semi-husked coconuts can be easily broken and are enriched with coconut water. The coconuts are fully mature and light brown in colour. While packing the coconuts, we make sure that the fresh coconuts remain intact.</p>
            <h4 class="text-theme-colored">Health Benefits</h4>
			<ul class="list">
				<li>High protein content</li>
				<li>Destroys intestinal parasites</li>
				<li>Good for kidney and urinary bladder problems</li>
			</ul>
			<div class="clearfix"></div>
            
              <div class="owl-carousel-4col mt-10" data-dots="true">
                <div class="item">
                  <div class="team-member maxwidth400">
                    <div class="thumb"><img alt="" src="images/products/coconut.jpg" class="img-fullwidth"></div>
                  </div>
                </div>
                <div class="item">
                  <div class="team-member maxwidth400">
                    <div class="thumb"><img alt="" src="images/products/coconut1.jpg" class="img-fullwidth"></div>
                  </div>
                </div>
                <div class="item">
                  <div class="team-member maxwidth400">
                    <div class="thumb"><img alt="" src="images/products/coconut2.jpg" class="img-fullwidth"></div>
                  </div>
                </div>
                <div class="item">
                  <div class="team-member maxwidth400">
                    <div class="thumb"><img alt="" src="images/products/coconut3.jpg" class="img-fullwidth"></div>
                  </div>
                </div>
              </div>
            <a href="pdf/Indian Coconuts-Geewin.pdf" download="Indian Coconuts-Geewin" class="pull-right btn bg-blue2 text-white">Download Brochure</a>
			<br/>
            <h4 class="text-theme-colored">Specifications of Indian Coconut</h4>
			  <div class="col-md-6">
            	<table class="table table-bordered table-inverse">
                	<tr>
                    	<th>Color</th>
                        <td>Light brown</td>
                    </tr>
                	<tr>
                    	<th>Grade</th>
                        <td>Semi husked</td>
                    </tr>
                	<tr>
                    	<th>Nut size</th>
                        <td>12 to 14 inches</td>
                    </tr>
                	<tr>
                    	<th>Self life</th>
                        <td>50 days from the date of packing</td>
                    </tr>
                	<tr>
                    	<th>Source</th>
                        <td>The land where the Palakkad Gap funnel (Western Ghats) winds blow on to the fields.</td>
                    </tr>
                </table>
			  </div>
			  
			  <div class="col-md-6">
            	<table class="table table-bordered table-inverse">
                	<tr>
                    	<th>Maturity</th>
                        <td>Matured</td>
                    </tr>
                	<tr>
                    	<th>Weight</th>
                        <td>500gm to 650gm</td>
                    </tr>
                	<tr>
                    	<th>Applications</th>
                        <td>Commercial,industrial and household use</td>
                    </tr>
                	<tr>
                    	<th>Unit price</th>
                        <td>per ton wise/bag wise</td>
                    </tr>
                </table>
			  </div>
			<div class="clearfix"></div>
			<h4 class="text-theme-colored">Availability</h4>
            <p>The coconut is cultivated in various parts of southern India and available all around the year. We help these coconut suppliers to sell their coconuts in the market.</p>
            <h4 class="text-theme-colored">Fresh Coconut Exporter - Geewin</h4>
			<p>We are one of the topmost Fresh Coconut exporters in India. We have been operating for many years and are dealing with a number of clients from various parts of the globe. Our services are unmatchable because of the excellence and the quality of our products. The coconuts provided by us are packed from farms directly. All types of coconuts are from naturally grown trees.While packing the coconuts, we make sure that our organic and fresh coconuts remain intact. The coconuts, which we supply, are widely used in various industries such as food and beverage, cosmetic and health & beauty care products.</p>

			<p>We deal with the reputed clients from these industries and make sure that they get the high quality products without any delay and compromise on quality.Coconuts we supply do not contain any adulteration or harmful elements. We follow the standards and do not compromise the high quality of our products. The coconuts are organically grown and they give amazing aroma, taste and enriched with nutrients. These are packed properly ensuring long shelf-life.The coconuts are also used in the hotels and by the end users. Geewin is one of the wholesalers of fresh husked coconut suppliers and has expanded the venture to various parts of the India and Globe.</p>	
            
			
			<h4 class="text-theme-colored">Nutritional Content Per 100 Gram</h4>
			  <div class="col-md-6">
            	<table class="table table-bordered table-inverse">
                	<tr>
                    	<th>Vitamin B</th>
                        <td>Thiamine- 10mg</td>
                    </tr>
                	<tr>
                    	<th>Calcium</th>
                        <td>21mg</td>
                    </tr>
                	<tr>
                    	<th>Phosphorus</th>
                        <td>98mg</td>
                    </tr>
                	<tr>
                    	<th>Carbohydrates</th>
                        <td>14gm</td>
                    </tr>
                	<tr>
                    	<th>Calories</th>
                        <td>359</td>
                    </tr>
                </table>
			  </div>
			  
			  <div class="col-md-6">
            	<table class="table table-bordered table-inverse">
                	<tr>
                    	<th>Vitamin C</th>
                        <td>2mg</td>
                    </tr>
                	<tr>
                    	<th>Iron</th>
                        <td>2.0mg</td>
                    </tr>
                	<tr>
                    	<th>Fat</th>
                        <td>34.7gm</td>
                    </tr>
                	<tr>
                    	<th>Protein</th>
                        <td>3.4gm</td>
                    </tr>
                </table>
			  </div>
			<div class="clearfix"></div>
			<p>Fresh coconut meat provides iron, potassium, protein and 346 calories per 3.5 ounces serving. The coconut contains saturated fat, quite unusual for fruits and vegetables. Coconut meat is used for preparing variety of spicy as well as sweet dishes. We export husked coconuts and semi-husked coconuts.</p>
			
			<h4 class="text-theme-colored">Packing</h4>
            <p>25 nuts per bag</p>
			
            <h4 class="text-theme-colored">Loadability</h4>
			<ul class="list">
				<li>Load ability of 20ft container : 950 bags</li>
				<li>Load ability of 40ft container : 1900/2000 bags</li>
			</ul>	
			
            <h4 class="text-theme-colored">Min. order quantity</h4>
			<p>1000 bags per 20ft container</p>
			
			<h4 class="text-theme-colored">Mode Of Payment Terms</h4>
				<p>advance payment / irrevocable L/C (with prime bank)</p>
			
            <h4 class="text-theme-colored">Delivery Time</h4>
            <p>5-10 days</p>
			
			</div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
  
  	
  <section id="contact" class="form-bg">
      <div class="container pt-0 pb-0">
  	    <div class="section-content">
          <div class="row">
          	<div class="col-md-12 text-center">
                <h1 class="mt-100 mb-30 blue1 ft-24">LET'S GET IN TOUCH</h1>
                <p class="mb-30 text-white">Here are the packages that we offer and they all include refreshments.</p>
          	</div>
            <div class="col-sm-12 col-md-12">
              <div class="contact-wrapper">

				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Error Message -->  
	<div id="success_message" style="width:100%; height:100%; display:none; text-align:center;"> <h3 class="text-white">Sent your message successfully!</h3> </div>
	<div class="text-white" id="error_message" style="width:100%; height:100%; display:none; text-align:center;"> <h3>Error</h3> Sorry there was an error sending your form. </div>
<!-- Error Message End--> 


<!-- Form Start -->               
	<form role="form" method="post" id="reused_form" >
		<div class="col-sm-12 col-md-6">
			<div class="form-group">   
	            <input type="text" class="form-control form-input" id="name" name="name" placeholder="Name" required maxlength="50">
			</div>
			<div class="form-group"> 
				<input type="email" class="form-control form-input" id="email" name="email" placeholder="Email"  required maxlength="50">
			</div>
			<div class="form-group">
				<input type="phone" class="form-control form-input" id="phone" name="phone" placeholder="Phone Number" required maxlength="50">
			</div>
			<div class="form-group">
				<input type="text" class="form-control form-input" id="city" name="city" placeholder="Your City / State / Country*" required maxlength="50">
			</div>
		</div>
		<div class="col-sm-12 col-md-6">
			<div class="form-group">
				<textarea class="form-control form-input" type="textarea" name="message" id="message" placeholder="Your Message Here" maxlength="6000" rows="7"></textarea>
			</div>
			<div class="form-group col-md-12" style="padding: 0;">
				<div class="form-group col-md-4" style="padding: 0;">
					<img src="mail/captcha.php" id="captcha_image" style="height: 45px;"/> <a id="captcha_reload" href="#"> <i class="fa fa-refresh fa-lg" style="color: white;"></i> </a> 
				</div>
				<div class="form-group col-md-8" style="padding: 0;">
					<input type="text" class="form-control form-input" placeholder="Enter the code from the image" required id="captcha" name="captcha" >
				</div>
			</div>
		</div>
        <div class="col-md-12 text-center mb-30">
			<input type="submit" class="btn bg-blue2 text-white" align="middle"  id="btnContactUs" value="SEND MESSAGE"></input>
		</div>
	</form>
	
<!-- Script for captcha load -->	
	
	<script type="text/javascript" src="./mail/form.js"></script>
<!-- Script for captcha load End-->	
              </div>
            </div>
          </div>
  	    </div>
      </div>
    </section>
  <!-- Footer -->
  
  <footer id="footer" class="bg-black-222" data-bg-img="images/footer-bg.png" data-bg-color="#e3e3e3">
    <div class="container pt-70 pb-30">
      <div class="row border-bottom-black">
        <div class="col-sm-6 col-md-6">
          <div class="widget dark text-center">
            <img class="mb-20" alt="" src="images/foot-logo.png">
            <p class="text-black-333">We GEEWIN EXIM, Madurai is one of the leading merchant exporters in India. We are supplying high quality of Cavendish banana, Rice, Fresh Vegetables, Indian Spices, Coconut, Coco peat, Cashew Nuts, Chickpeas, Chilly in large volumes to our customers’ spread through out the world. We are based at Madurai the hub of Exporter’s House. We here the capability to deliver large volumes with in stipulated time schedules.</p>
          </div>
        </div>
        <!--<div class="col-sm-6 col-md-2">
          <div class="widget">
            <h5 class="widget-title line-bottom blue1">Profile</h5>
            <ul class="list angle-double-right list-border">
                <li><a href="about.html">About Us</a></li>
                <li><a href="profile.html#vsnmsn">Vision &amp; Mission</a></li>
                <li><a href="management-team.html">Management team</a></li>
                <li><a href="infrastructure.html">Infrastructure</a></li>
                <li><a href="profile.html#qual">Quality assurance</a></li>
        				<li><a href="profile.html#why">Why us</a></li>
        				<li><a href="profile.html#client">Clientele</a></li>
        				<li><a href="profile.html#test">Testimonial</a></li>
            </ul>
          </div>
        </div> -->
        <div class="col-sm-6 col-md-6 text-center">
          <div class="widget">
            <h5 class="widget-title blue1">OUR PRODUCTS</h5>

            <div class="tags">
              <a class="hvr-shrink" href="cavendish-banana.php">Cavendish Banana</a>
              <a class="hvr-shrink" href="indian-coconut.php">Indian Coconut</a>
              <a class="hvr-shrink" href="indian-rice.php">Indian Rice</a>
              <a class="hvr-shrink" href="coir-fiber.php">Coir Fiber</a>
              <a class="hvr-shrink" href="cocopeat-block.php">Cocopeat Block</a>
              <a class="hvr-shrink" href="gherkins.php">Gherkins</a>
				      <a class="hvr-shrink" href="indian-spices.php">Indian Spices</a>
              <a class="hvr-shrink" href="turmeric-finger.php">Turmeric Finger</a>
              <a class="hvr-shrink" href="dry-red-chilly.php">Dry Red Chilli</a>
            
              <a class="hvr-shrink" href="nuts.php">Nuts</a>
              <a class="hvr-shrink" href="grains-and-pulses.php">Grains and Pulses</a>
              <a class="hvr-shrink" href="chicken-eggs.php">Chicken Eggs</a>
              <a class="hvr-shrink" href="safety-matches.php">Safety Matches</a>
              <a class="hvr-shrink" href="onion.php">Onion</a>
              <a class="hvr-shrink" href="potato.php">Potato</a>
              <a class="hvr-shrink" href="fresh-vegetables.php">Fresh Vegetables</a>
              <a class="hvr-shrink" href="coconut-copra.php">Coconut Copra</a><br/>
			  <a class="hvr-shrink" href="event.php">Events</a>
             
          </div>
        </div>
      
      </div>
      </div>
      <div class="row mt-30">
        <div class="col-md-3">
          <div class="widget dark">
            
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10 text-black-333"> <i class="fa fa-map blue2 mr-5"></i> No.14, Sonaiyar Kovil Street, <br> Narimedu, Madurai, <br> Tamilnadu, India – 625 002.</li>
            </ul>

          </div>
        </div>
        <div class="col-md-3 col-md-offset-1">
          <div class="widget dark">
            
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10 text-black-333"><a href="tel:+919159773337"> <i class="fa fa-whatsapp blue2 mr-5"></i> +91 9159773337</a></li>
              <li class="m-0 pl-10 pr-10 text-black-333"> <i class="fa fa-skype blue2 mr-5"></i> Geewinexim</li>
            </ul>

          </div>
        </div>
        <div class="col-md-3">
          <div class="widget dark">
            <h5 class="widget-title mb-10 blue1">Connect With Us</h5>
            <ul class="styled-icons icon-dark icon-circled icon-sm">
              <li><a href="https://www.facebook.com/geewineximexporters/" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/EximGeewin" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="http://linkedin.com/company/geewineximindia" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.youtube.com/channel/UCqxAHV_Sv6_k3mzVMMu_Lww" target="_blank"><i class="fa fa-youtube"></i></a></li>
              <li><a href="https://www.instagram.com/geewinexim/" target="_blank"><i class="fa fa-instagram"></i></a></li>
              <li><a href="https://pinterest.com/geewineximexport/" target="_blank"><i class="fa fa-pinterest"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom bg-black-333">
      <div class="container pt-20 pb-20">
        <div class="row">
          <div class="col-md-6">
            <p class="font-11 text-gray-lighter pt-20 m-0">Copyright &copy;2022. All Rights Reserved</p>
          </div>
          <div class="col-md-6 text-right">
            <div class="no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12 text-gray-lighter">
                <li>
                  Design and Marketed By <a href="http://onedotm.com/" target="_blank"><img src="images/onedotlogo.png" alt="onedot media" width="70"></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>


  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-129500425-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-129500425-1');
</script>                  
 <!--        
<script>
document.addEventListener('contextmenu', event => event.preventDefault());
</script> -->

<script>(function(w, d) { w.CollectId = "5f7174beb54ea90b9bbc4d39"; var h = d.head || d.getElementsByTagName("head")[0]; var s = d.createElement("script"); s.setAttribute("type", "text/javascript"); s.async=true; s.setAttribute("src", "https://collectcdn.com/launcher.js"); h.appendChild(s); })(window, document);</script>
  
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>
</html>