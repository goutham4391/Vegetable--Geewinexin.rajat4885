  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>easyData - open source & free solutions</title>
    <!-- Icon -->
    <link
      rel="icon"
      href="https://easy-data.mdbgo.io/img/favicon/favicon-32x32.png"
      type="image/x-icon"
    />
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.11.2/css/all.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap"
    />
    <!-- MDB UI KIT -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <!-- Custom styles -->
    <style></style>
  </head>

  <body>
    <!--Main Navigation-->
    <!-- <header class="mb-10"></header> -->
    <!--Main Navigation-->

    <!--Main layout-->
    <main>
      <div class="container">
        <!-- Table -->
        <table class="table">
          <thead id="table-head"></thead>
          <tbody id="table-body"></tbody>
        </table>
        <!-- Table -->
      </div>
    </main>
    <!--Main layout-->

  </body>

  <!-- MDB ESSENTIAL -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Google API -->
  <script src="https://apis.google.com/js/api.js"></script>
  <!-- easyData -->
  <script type="text/javascript" src="js/easyData-google-sheets.js"></script>

  <!-- easyData - Creating table -->
  <script>
    {
      {
        // Your API KEY
        const API_KEY = "AIzaSyDluKDhFGiUyqEaPgwWdJkYXGjcajELr2Y";

        function displayResult2(response) {
          let tableHead = "";
          let tableBody = "";

          response.result.values.forEach((row, index) => {
            if (index === 0) {
              tableHead += "<tr>";
              row.forEach((val) => (tableHead += "<th>" + val + "</th>"));
              tableHead += "</tr>";
            } else {
              tableBody += "<tr>";
              row.forEach((val) => (tableBody += "<td>" + val + "</td>"));
              tableBody += "</tr>";
            }
          });

          document.getElementById("table-head").innerHTML = tableHead;
          document.getElementById("table-body").innerHTML = tableBody;
        }

        function loadData() {
          // Spreadsheet ID
          const spreadsheetId = "1pnCi13dDb1DgZRlb7nzBq37avffQJvzdwZLBVMCGq60";
          const range = "A:Z";
          getPublicValues({ spreadsheetId, range }, displayResult2);
        }

        window.addEventListener("load", (e) => {
          initOAuthClient({ apiKey: API_KEY });
        });

        document.addEventListener("gapi-loaded", (e) => {
          loadData();
        });
      }
    }
  </script>
